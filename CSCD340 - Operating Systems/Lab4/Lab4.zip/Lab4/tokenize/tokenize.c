#include "tokenize.h"

void clean(int argc, char **argv)
{



}// end clean

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s\n", argv[x]);

}// end printargs

int makeargs(char *s, char *** argv)
{

   return -1;

}// end makeArgs
